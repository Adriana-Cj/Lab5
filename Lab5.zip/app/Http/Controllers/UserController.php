<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function index()
    {
        if (! Gate::allows('view-users')) {
            abort(403);
        }
        $users = User::all();
        return view('admin.users', compact('users'));
    }

    public function showDashboard($id = null)
    {
        if ($id) {
            if (! Gate::allows('view-any-dashboard')) {
                abort(403);
            }
            $user = User::findOrFail($id);
        } else {
            $user = Auth::user();
        }
        
        return view('dashboard', compact('user'));
    }
}