<?php

namespace App\Providers;

use Illuminate\Support\Facades\Gate;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    public function boot()
    {
        Gate::define('view-users', function ($user) {
            return $user->isAdmin();
        });

        Gate::define('view-any-dashboard', function ($user) {
            return $user->isAdmin();
        });
    }
}