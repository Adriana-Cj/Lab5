<!DOCTYPE html>
<html>
<head>
    <title>Dashboard | <?php echo e(config('app.name')); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #4f46e5;
            --primary-dark: #4338ca;
            --secondary: #64748b;
            --success: #22c55e;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #3b82f6;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d1d5db;
            --gray-800: #1f2937;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--gray-100);
            color: var(--gray-800);
            line-height: 1.5;
        }

        .dashboard {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            background: white;
            padding: 1.5rem;
            border-right: 1px solid var(--gray-200);
        }

        .brand {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 2rem;
        }

        .nav-menu {
            list-style: none;
        }

        .nav-item {
            margin-bottom: 0.5rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem 1rem;
            color: var(--secondary);
            text-decoration: none;
            border-radius: 0.5rem;
            transition: all 0.2s;
        }

        .nav-link:hover {
            background: var(--gray-100);
            color: var(--primary);
        }

        .nav-link.active {
            background: var(--primary);
            color: white;
        }

        /* Main Content Styles */
        .main-content {
            padding: 2rem;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        .user-welcome {
            font-size: 1.5rem;
            font-weight: 600;
        }

        .logout-form button {
            background: var(--danger);
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.2s;
        }

        .logout-form button:hover {
            background: #dc2626;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 1rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .stat-card h3 {
            color: var(--secondary);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.5rem;
        }

        .stat-card p {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--gray-800);
        }

        /* Activity Section */
        .activity-section {
            background: white;
            padding: 1.5rem;
            border-radius: 1rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .activity-section h2 {
            margin-bottom: 1rem;
            font-size: 1.25rem;
        }

        .activity-list {
            list-style: none;
        }

        .activity-item {
            padding: 1rem 0;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .activity-icon {
            width: 2.5rem;
            height: 2.5rem;
            background: var(--gray-100);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
        }

        /* Admin Section */
        .admin-section {
            margin-top: 2rem;
            background: white;
            padding: 1.5rem;
            border-radius: 1rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .admin-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }

        .admin-action-btn {
            padding: 1rem;
            border: 1px solid var(--gray-200);
            border-radius: 0.5rem;
            text-decoration: none;
            color: var(--gray-800);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            transition: all 0.2s;
        }

        .admin-action-btn:hover {
            background: var(--gray-100);
            border-color: var(--primary);
            color: var(--primary);
        }

        @media (max-width: 768px) {
            .dashboard {
                grid-template-columns: 1fr;
            }
            
            .sidebar {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="brand"><?php echo e(config('app.name')); ?></div>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="#" class="nav-link active">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="fas fa-user"></i>
                        Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="fas fa-bell"></i>
                        Notifications
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <h1 class="user-welcome">Welcome back, <?php echo e($user->name); ?>!</h1>
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="logout-form">
                    <?php echo csrf_field(); ?>
                    <button type="submit">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </button>
                </form>
            </div>

            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Account Status</h3>
                    <p>
                        <i class="fas fa-circle" style="color: var(--success); font-size: 0.75rem;"></i>
                        Active
                    </p>
                </div>
                <div class="stat-card">
                    <h3>Last Login</h3>
                    <p><?php echo e(now()->format('M d, H:i')); ?></p>
                </div>
                <div class="stat-card">
                    <h3>Email Status</h3>
                    <p>
                        <?php if(auth()->user()->email_verified_at): ?>
                            <i class="fas fa-check-circle" style="color: var(--success);"></i> Verified
                        <?php else: ?>
                            <i class="fas fa-exclamation-circle" style="color: var(--warning);"></i> Pending
                        <?php endif; ?>
                    </p>
                </div>
                <div class="stat-card">
                    <h3>Member Since</h3>
                    <p><?php echo e($user->created_at->format('M d, Y')); ?></p>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="activity-section">
                <h2>Recent Activity</h2>
                <ul class="activity-list">
                    <li class="activity-item">
                        <div class="activity-icon">
                            <i class="fas fa-sign-in-alt"></i>
                        </div>
                        <div>
                            <strong>System Login</strong>
                            <p>Successful login from <?php echo e(request()->ip()); ?></p>
                        </div>
                    </li>
                    <li class="activity-item">
                        <div class="activity-icon">
                            <i class="fas fa-user-edit"></i>
                        </div>
                        <div>
                            <strong>Profile Update</strong>
                            <p>Profile information was updated</p>
                        </div>
                    </li>
                </ul>
            </div>

            <?php if(auth()->user()->isAdmin()): ?>
            <!-- Admin Section -->
            <div class="admin-section">
                <h2>Administrative Actions</h2>
                <div class="admin-actions">
                    <a href="<?php echo e(route('users.index')); ?>" class="admin-action-btn">
                        <i class="fas fa-users"></i>
                        Manage Users
                    </a>
                    <a href="#" class="admin-action-btn">
                        <i class="fas fa-chart-line"></i>
                        Analytics
                    </a>
                    <a href="#" class="admin-action-btn">
                        <i class="fas fa-cogs"></i>
                        System Settings
                    </a>
                    <a href="#" class="admin-action-btn">
                        <i class="fas fa-shield-alt"></i>
                        Security Logs
                    </a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\auth-project\resources\views/dashboard.blade.php ENDPATH**/ ?>