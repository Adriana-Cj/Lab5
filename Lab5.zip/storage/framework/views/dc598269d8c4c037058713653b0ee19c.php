<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel</title>
    <style>
        :root {
            --primary-color: #4f46e5;
            --primary-hover: #4338ca;
            --text-color: #1f2937;
            --text-muted: #6b7280;
            --border-color: #e5e7eb;
            --bg-color: #f3f4f6;
            --white: #ffffff;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.5;
            background: var(--bg-color);
            color: var(--text-color);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }

        .container {
            width: 100%;
            max-width: 800px;
            background: var(--white);
            border-radius: 1rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 
                        0 2px 4px -1px rgba(0, 0, 0, 0.06);
            padding: 2rem;
            position: relative;
        }

        .nav {
            position: absolute;
            top: 2rem;
            right: 2rem;
            display: flex;
            gap: 1.5rem;
        }

        .nav a {
            color: var(--text-color);
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            transition: all 0.15s ease;
        }

        .nav a:hover {
            background: var(--bg-color);
            color: var(--primary-color);
        }

        .welcome-content {
            text-align: center;
            padding: 4rem 2rem;
        }

        .welcome-content h1 {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--text-color);
            margin-bottom: 1rem;
            line-height: 1.2;
        }

        .welcome-content p {
            font-size: 1.125rem;
            color: var(--text-muted);
            max-width: 600px;
            margin: 0 auto;
        }

        /* Responsive adjustments */
        @media (max-width: 640px) {
            .container {
                padding: 1.5rem;
            }

            .nav {
                position: relative;
                top: 0;
                right: 0;
                justify-content: center;
                margin-bottom: 2rem;
            }

            .welcome-content {
                padding: 2rem 1rem;
            }

            .welcome-content h1 {
                font-size: 2rem;
            }

            .welcome-content p {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if(Route::has('login')): ?>
            <div class="nav">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>">Log in</a>
                    <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>">Înregistrare</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="welcome-content">
            <h1>Bine ai venit!</h1>
            <p>Autentifică-te pentru o experiență de neuitat!</p>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\auth-project\resources\views/welcome.blade.php ENDPATH**/ ?>